import { New } from './index';

interface Duda extends ReturnType<typeof New> {
}
